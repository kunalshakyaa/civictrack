# CivicTrack

A civic-issue reporting platform: a dark, cinematic landing page (`/`) plus a
real, working app (`/app`) with a live map, database-backed reporting, and
real-time citizen-to-citizen comments.

## What's real vs. what's a mockup

- **`/` (landing page)** — marketing page with a static app *preview* mockup. No live data.
- **`/app` (live app)** — the real thing: a Leaflet map reading/writing to a
  real Postgres database (via Supabase), live-updating for every connected
  visitor through Supabase Realtime, plus a comment thread per issue.

Nothing here needs a paid API key. Supabase's free tier and OpenStreetMap
tiles are both used.

## 1. Set up your database (Supabase — free)

1. Go to https://supabase.com, sign up, and create a new project (pick any
   name/region; note the database password somewhere safe).
2. Once the project is ready, open **SQL Editor** in the left sidebar, paste
   in the contents of `supabase/schema.sql` from this repo, and run it. This
   creates the `issues` and `comments` tables, sets up public read/write
   policies for this open, no-login demo, and enables realtime.
3. Go to **Storage** in the sidebar, click **New bucket**, name it exactly
   `photos`, and toggle **Public bucket** on. This is where report photos
   are stored.
4. Go to **Project Settings -> API**. Copy the **Project URL** and the
   **anon public** key.

## 2. Connect the app to your database

1. In this project's root folder, copy `.env.example` to a new file named
   `.env`.
2. Paste your Project URL and anon key into it:
   ```
   VITE_SUPABASE_URL=https://your-project-id.supabase.co
   VITE_SUPABASE_ANON_KEY=your-anon-public-key
   ```
3. Restart the dev server if it's running (`Ctrl+C`, then `npm run dev`
   again) so Vite picks up the new environment variables.

Without a `.env` file, `/app` still loads but shows a short "connect your
database" notice instead of the map/report form/comments — the landing
page is unaffected either way.

## 3. Run it locally

```
npm install
npm run dev
```

Open the printed URL (usually http://localhost:5173). Visit `/app` to use
the live map and reporting.

## 4. Deploy it for real

The easiest free path is **Vercel**:

1. Push this project to a GitHub repository.
2. Go to https://vercel.com, sign in with GitHub, and click **Add New ->
   Project**, then select your repo. Vercel auto-detects Vite.
3. Before deploying, add your environment variables under **Settings ->
   Environment Variables**: `VITE_SUPABASE_URL` and
   `VITE_SUPABASE_ANON_KEY` (same values as your `.env`).
4. Click **Deploy**. You'll get a live `https://your-project.vercel.app`
   URL that anyone can open — the map and comments will work for every
   visitor in real time, backed by your Supabase database.

Netlify works the same way if you prefer it instead.

## Project structure

```
civictrack/
├── supabase/schema.sql       # run this once in Supabase's SQL Editor
├── .env.example              # copy to .env and fill in your credentials
├── src/
│   ├── lib/supabaseClient.js # Supabase connection + readiness check
│   ├── App.jsx                # routes: "/" landing, "/app" live app
│   ├── CivicTrackLanding.jsx  # marketing landing page
│   ├── LiveApp.jsx            # live app shell (map/report tabs)
│   ├── MapView.jsx            # real-time map of issues
│   ├── ReportForm.jsx         # submits real issues (+ optional photo)
│   └── IssueComments.jsx      # real-time per-issue comment thread
```

## Notes and honest limitations

- **No login/auth** — anyone can report, upvote, or comment, similar to how
  many civic-tip lines work. Add Supabase Auth if you need accountability
  or moderation before opening this to the public.
- **Open write policies** — the SQL schema uses permissive Row Level
  Security policies to keep the demo simple. Before real-world use, add
  rate limiting and/or require authentication for writes.
- **Background** on the landing page is a fully code-generated animated
  skyline (SVG + CSS) — no external video/image assets.
