import { useEffect, useState } from "react";
import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import { supabase, supabaseReady } from "./lib/supabaseClient";
import { getIssues, subscribeIssues, upvoteIssue as localUpvote } from "./lib/localStore";

// Vite bundles leaflet's default marker images oddly — point them at the CDN instead.
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png",
  iconUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",
  shadowUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
});

const CATEGORY_LABEL = {
  streetlight: "Streetlight",
  water: "Water Leakage",
  garbage: "Garbage",
  road: "Road / Pothole",
  other: "Other",
};

export default function MapView({ onSelectIssue, selectedId }) {
  const [issues, setIssues] = useState([]);
  const [center, setCenter] = useState([28.6139, 77.209]); // fallback: Delhi

  // Try to center the map on the visitor's own location
  useEffect(() => {
    if (!navigator.geolocation) return;
    navigator.geolocation.getCurrentPosition(
      (pos) => setCenter([pos.coords.latitude, pos.coords.longitude]),
      () => {} // silently keep the fallback center if denied
    );
  }, []);

  // Load existing issues, then subscribe to live inserts/updates/deletes.
  // Falls back to a localStorage-backed demo store when Supabase isn't
  // configured, so the map still works end-to-end without a backend.
  useEffect(() => {
    if (!supabaseReady) {
      setIssues(getIssues());
      const unsubscribe = subscribeIssues(setIssues);
      return unsubscribe;
    }

    let channel;
    (async () => {
      const { data } = await supabase
        .from("issues")
        .select("*")
        .order("created_at", { ascending: false });
      setIssues(data || []);

      channel = supabase
        .channel("issues-realtime")
        .on(
          "postgres_changes",
          { event: "*", schema: "public", table: "issues" },
          (payload) => {
            setIssues((prev) => {
              if (payload.eventType === "INSERT") return [payload.new, ...prev];
              if (payload.eventType === "UPDATE")
                return prev.map((i) => (i.id === payload.new.id ? payload.new : i));
              if (payload.eventType === "DELETE")
                return prev.filter((i) => i.id !== payload.old.id);
              return prev;
            });
          }
        )
        .subscribe();
    })();

    return () => {
      if (channel) supabase.removeChannel(channel);
    };
  }, []);

  const upvote = async (issue) => {
    if (!supabaseReady) {
      localUpvote(issue.id);
      return;
    }
    await supabase.from("issues").update({ upvotes: issue.upvotes + 1 }).eq("id", issue.id);
  };

  return (
    <div style={{ position: "relative", height: "100%", width: "100%" }}>
      {!supabaseReady && (
        <div
          style={{
            position: "absolute",
            top: 10,
            left: 10,
            zIndex: 1000,
            background: "rgba(13,31,23,0.85)",
            color: "#95D5B2",
            fontSize: 11,
            fontWeight: 600,
            padding: "4px 10px",
            borderRadius: 999,
            border: "1px solid rgba(255,255,255,0.15)",
          }}
        >
          Demo mode · saved on this device
        </div>
      )}
      <MapContainer center={center} zoom={13} style={{ height: "100%", width: "100%" }}>
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        {issues.map((issue) => (
          <Marker
            key={issue.id}
            position={[issue.lat, issue.lng]}
            eventHandlers={{ click: () => onSelectIssue?.(issue) }}
          >
            <Popup>
              <div style={{ minWidth: 180 }}>
                <strong>{issue.title}</strong>
                <div style={{ fontSize: 12, color: "#555", marginTop: 4 }}>
                  {CATEGORY_LABEL[issue.category] || issue.category} · {issue.status}
                </div>
                {issue.description && (
                  <p style={{ fontSize: 12, marginTop: 6 }}>{issue.description}</p>
                )}
                {issue.photo_url && (
                  <img
                    src={issue.photo_url}
                    alt=""
                    style={{ marginTop: 6, width: "100%", borderRadius: 6 }}
                  />
                )}
                <button
                  onClick={() => upvote(issue)}
                  style={{
                    marginTop: 8,
                    fontSize: 12,
                    padding: "4px 10px",
                    borderRadius: 999,
                    background: "#111",
                    color: "#fff",
                    border: "none",
                    cursor: "pointer",
                  }}
                >
                  ▲ Upvote ({issue.upvotes})
                </button>
              </div>
            </Popup>
          </Marker>
        ))}
      </MapContainer>
    </div>
  );
}
