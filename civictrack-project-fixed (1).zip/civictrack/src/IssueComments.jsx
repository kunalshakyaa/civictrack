import { useEffect, useState } from "react";
import { supabase, supabaseReady } from "./lib/supabaseClient";
import { getComments, addComment, subscribeComments } from "./lib/localStore";

export default function IssueComments({ issue }) {
  const [comments, setComments] = useState([]);
  const [name, setName] = useState("");
  const [text, setText] = useState("");

  useEffect(() => {
    if (!issue) {
      setComments([]);
      return;
    }

    if (!supabaseReady) {
      setComments(getComments(issue.id));
      return subscribeComments(issue.id, setComments);
    }

    let channel;
    (async () => {
      const { data } = await supabase
        .from("comments")
        .select("*")
        .eq("issue_id", issue.id)
        .order("created_at", { ascending: true });
      setComments(data || []);

      channel = supabase
        .channel(`comments-${issue.id}`)
        .on(
          "postgres_changes",
          { event: "INSERT", schema: "public", table: "comments", filter: `issue_id=eq.${issue.id}` },
          (payload) => setComments((prev) => [...prev, payload.new])
        )
        .subscribe();
    })();

    return () => {
      if (channel) supabase.removeChannel(channel);
    };
  }, [issue?.id]);

  const send = async (e) => {
    e.preventDefault();
    if (!text.trim()) return;
    if (!supabaseReady) {
      addComment({ issue_id: issue.id, author: name, text: text.trim() });
      setText("");
      return;
    }
    await supabase.from("comments").insert({
      issue_id: issue.id,
      author: name.trim() || "Anonymous",
      text: text.trim(),
    });
    setText("");
  };

  if (!issue) {
    return (
      <div className="p-6 text-white/40 text-sm h-full flex items-center justify-center text-center">
        Select an issue on the map to view and join the discussion.
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full p-4">
      <h3 className="text-white font-semibold text-sm mb-1">{issue.title}</h3>
      <p className="text-white/40 text-xs mb-4">Discussion · updates in real time</p>

      <div className="flex-1 overflow-y-auto space-y-2 mb-3 pr-1">
        {comments.map((c) => (
          <div key={c.id} className="text-xs text-white/80 bg-white/5 rounded-lg px-3 py-2">
            <span className="font-semibold text-white/90">{c.author}: </span>
            {c.text}
          </div>
        ))}
        {comments.length === 0 && (
          <div className="text-xs text-white/40">No messages yet — be the first to comment.</div>
        )}
      </div>

      <form onSubmit={send} className="flex flex-col gap-2">
        <input
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Your name (optional)"
          className="bg-black/30 border border-white/10 rounded-lg px-3 py-2 text-xs text-white"
        />
        <div className="flex gap-2">
          <input
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="Write a comment..."
            className="flex-1 bg-black/30 border border-white/10 rounded-lg px-3 py-2 text-xs text-white"
          />
          <button className="bg-white text-black rounded-lg px-3 py-2 text-xs font-medium hover:bg-white/90 transition-colors">
            Send
          </button>
        </div>
      </form>
    </div>
  );
}
