import { useState } from "react";
import { supabase, supabaseReady } from "./lib/supabaseClient";
import { addIssue, fileToDataUrl } from "./lib/localStore";

const CATEGORIES = [
  { value: "streetlight", label: "Streetlight" },
  { value: "water", label: "Water Leakage" },
  { value: "garbage", label: "Garbage" },
  { value: "road", label: "Road / Pothole" },
  { value: "other", label: "Other" },
];

export default function ReportForm({ onDone }) {
  const [category, setCategory] = useState("streetlight");
  const [description, setDescription] = useState("");
  const [photo, setPhoto] = useState(null);
  const [coords, setCoords] = useState(null);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);

  const useMyLocation = () => {
    setError("");
    navigator.geolocation.getCurrentPosition(
      (pos) => setCoords({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
      () => setError("Could not get your location. Allow location access and try again.")
    );
  };

  const submit = async (e) => {
    e.preventDefault();
    if (!coords) {
      setError("Please share your location first.");
      return;
    }
    setSubmitting(true);
    setError("");

    try {
      if (!supabaseReady) {
        // Demo mode: no backend configured — save the report right on this
        // device (localStorage) so it's real and persists, just not shared
        // with other visitors yet. Connect Supabase to make it fully live.
        const photo_url = photo ? await fileToDataUrl(photo) : null;
        addIssue({
          title: description.trim().slice(0, 60) || "Untitled issue",
          description: description.trim(),
          category,
          lat: coords.lat,
          lng: coords.lng,
          photo_url,
        });
      } else {
        let photo_url = null;
        if (photo) {
          const path = `${Date.now()}-${photo.name}`.replace(/\s+/g, "-");
          const { error: upErr } = await supabase.storage.from("photos").upload(path, photo);
          if (upErr) throw upErr;
          const { data } = supabase.storage.from("photos").getPublicUrl(path);
          photo_url = data.publicUrl;
        }

        const { error: insErr } = await supabase.from("issues").insert({
          title: description.trim().slice(0, 60) || "Untitled issue",
          description: description.trim(),
          category,
          lat: coords.lat,
          lng: coords.lng,
          photo_url,
          status: "Reported",
          upvotes: 0,
        });
        if (insErr) throw insErr;
      }

      setSuccess(true);
      setDescription("");
      setPhoto(null);
      setCoords(null);
      setTimeout(() => {
        setSuccess(false);
        onDone?.();
      }, 1200);
    } catch (err) {
      setError(err.message || "Something went wrong. Please try again.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <form onSubmit={submit} className="flex flex-col gap-4 p-6 max-w-md mx-auto">
      <h2 className="text-white text-lg font-semibold">Report an issue</h2>
      {!supabaseReady && (
        <div className="text-[11px] text-[#95D5B2] bg-white/5 border border-white/10 rounded-lg px-3 py-2">
          Demo mode: no database connected yet, so this report is saved on
          this device only (not shared with other visitors). Connect
          Supabase to make it fully live.
        </div>
      )}

      <label className="text-xs text-white/60">Category</label>
      <select
        value={category}
        onChange={(e) => setCategory(e.target.value)}
        className="bg-black/30 border border-white/10 rounded-lg px-3 py-2 text-sm text-white"
      >
        {CATEGORIES.map((c) => (
          <option key={c.value} value={c.value}>{c.label}</option>
        ))}
      </select>

      <label className="text-xs text-white/60">Description</label>
      <textarea
        value={description}
        onChange={(e) => setDescription(e.target.value)}
        maxLength={150}
        placeholder="Brief description (max 150 characters)"
        className="bg-black/30 border border-white/10 rounded-lg px-3 py-2 text-sm text-white h-24 resize-none"
      />
      <div className="text-[10px] text-white/30 -mt-2">{description.length}/150</div>

      <label className="text-xs text-white/60">Photo (optional)</label>
      <input
        type="file"
        accept="image/*"
        onChange={(e) => setPhoto(e.target.files?.[0] || null)}
        className="text-xs text-white/60 file:mr-3 file:rounded-full file:border-0 file:bg-white file:text-black file:px-3 file:py-1.5 file:text-xs file:font-medium"
      />

      <button
        type="button"
        onClick={useMyLocation}
        className="text-xs text-left underline underline-offset-2 text-white/70 hover:text-white transition-colors"
      >
        {coords ? `Location set (${coords.lat.toFixed(4)}, ${coords.lng.toFixed(4)})` : "Use my current location"}
      </button>

      {error && <div className="text-xs text-red-400">{error}</div>}
      {success && <div className="text-xs text-[#95D5B2]">Reported! Thank you.</div>}

      <button
        type="submit"
        disabled={submitting}
        className="bg-white text-black rounded-full px-5 py-2.5 text-sm font-medium disabled:opacity-50 hover:bg-white/90 transition-colors"
      >
        {submitting ? "Submitting..." : "Submit report"}
      </button>
    </form>
  );
}
