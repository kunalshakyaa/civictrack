import { BrowserRouter, Routes, Route } from "react-router-dom";
import CivicTrackLanding from "./CivicTrackLanding";
import LiveApp from "./LiveApp";

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<CivicTrackLanding />} />
        <Route path="/app" element={<LiveApp />} />
      </Routes>
    </BrowserRouter>
  );
}
