import React, { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import {
  MapPin, ChevronRight, Menu, Search, Camera, ArrowUp, Share2, Flag,
  Archive, Sparkles, Inbox, Star, Send, FileText, Trash2, MoreHorizontal,
  Check, X
} from "lucide-react";

/* ---------------------------------------------------------
   Shared primitives
--------------------------------------------------------- */

function LogoMark({ className = "w-8 h-8" }) {
  return (
    <svg viewBox="0 0 256 256" className={className} fill="white">
      <path d="M 0 128 C 70.692 128 128 185.308 128 256 L 64 256 C 64 220.654 35.346 192 0 192 Z" />
      <path d="M 256 192 C 220.654 192 192 220.654 192 256 L 128 256 C 128 185.308 185.308 128 256 128 Z" />
      <path d="M 128 0 C 128 70.692 70.692 128 0 128 L 0 64 C 35.346 64 64 35.346 64 0 Z" />
      <path d="M 192 0 C 192 35.346 220.654 64 256 64 L 256 128 C 185.308 128 128 70.692 128 0 Z" />
    </svg>
  );
}

function ReportButton({ label = "Report an Issue", full = false }) {
  const ref = useRef(null);
  const [offset, setOffset] = useState({ x: 0, y: 0 });

  const onMove = (e) => {
    const el = ref.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const x = (e.clientX - rect.left - rect.width / 2) * 0.3;
    const y = (e.clientY - rect.top - rect.height / 2) * 0.3;
    setOffset({ x, y });
  };
  const onLeave = () => setOffset({ x: 0, y: 0 });

  return (
    <button
      ref={ref}
      onMouseMove={onMove}
      onMouseLeave={onLeave}
      data-cursor-hover
      data-cursor-label="Report"
      style={{
        transform: `translate(${offset.x}px, ${offset.y}px)`,
        transition: "transform 0.15s cubic-bezier(.22,1,.36,1)",
      }}
      className={`group inline-flex items-center justify-center gap-2 rounded-full bg-white text-black font-medium text-sm px-5 py-3 hover:bg-white/90 active:scale-[0.98] ${
        full ? "w-full" : ""
      }`}
    >
      <MapPin className="w-4 h-4" />
      {label}
      <ChevronRight className="w-4 h-4 transition-transform group-hover:translate-x-[2px]" />
    </button>
  );
}

function SectionEyebrow({ label, tag }) {
  return (
    <div className="flex items-center gap-2">
      <span className="w-1.5 h-1.5 rounded-full bg-white" />
      <span className="text-xs font-medium text-white/60 tracking-wide">{label}</span>
      {tag && (
        <span className="px-2 py-0.5 rounded-full border border-white/10 text-white/50 text-[11px]">
          {tag}
        </span>
      )}
    </div>
  );
}

/**
 * FadeIn — reveals on scroll (IntersectionObserver) rather than only on mount.
 * Elements already in the viewport on load (e.g. the hero) reveal immediately
 * using `delay`; elements further down the page reveal the first time they
 * scroll into view, each with its own small stagger.
 */
function FadeIn({ children, delay = 0, y = 20, className = "" }) {
  const ref = useRef(null);
  const [show, setShow] = useState(false);

  useEffect(() => {
    const node = ref.current;
    if (!node) return;
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          const t = setTimeout(() => setShow(true), delay * 1000);
          observer.disconnect();
          return () => clearTimeout(t);
        }
      },
      { threshold: 0.15, rootMargin: "0px 0px -40px 0px" }
    );
    observer.observe(node);
    return () => observer.disconnect();
  }, [delay]);

  return (
    <div
      ref={ref}
      className={className}
      style={{
        opacity: show ? 1 : 0,
        transform: show ? "translateY(0)" : `translateY(${y}px)`,
        transition: "opacity 0.7s cubic-bezier(.22,1,.36,1), transform 0.7s cubic-bezier(.22,1,.36,1)",
        willChange: "opacity, transform",
      }}
    >
      {children}
    </div>
  );
}

/* ---------------------------------------------------------
   Animated background — a fully code-generated night city
   skyline: silhouetted buildings with twinkling windows,
   pulsing streetlamps, drifting fog, and a passing light trail.
   Pure SVG + CSS, no external video/image assets required.
--------------------------------------------------------- */

const SKYLINE_BUILDINGS = [
  { x: 0, w: 70, h: 130 }, { x: 70, w: 45, h: 90 }, { x: 115, w: 80, h: 175 },
  { x: 195, w: 55, h: 110 }, { x: 250, w: 60, h: 155 }, { x: 310, w: 40, h: 85 },
  { x: 350, w: 75, h: 195 }, { x: 425, w: 55, h: 120 }, { x: 480, w: 45, h: 95 },
  { x: 525, w: 70, h: 165 }, { x: 595, w: 50, h: 105 }, { x: 645, w: 65, h: 185 },
  { x: 710, w: 45, h: 90 }, { x: 755, w: 60, h: 145 }, { x: 815, w: 55, h: 115 },
  { x: 870, w: 70, h: 170 }, { x: 940, w: 60, h: 130 },
];

function Skyline() {
  return (
    <svg
      viewBox="0 0 1000 260"
      preserveAspectRatio="xMidYMax slice"
      className="absolute inset-0 w-full h-full"
    >
      {SKYLINE_BUILDINGS.map((b, bi) => {
        const cols = Math.max(2, Math.floor(b.w / 14));
        const rows = Math.max(3, Math.floor(b.h / 18));
        const winW = 5, winH = 7;
        const padX = (b.w - cols * (winW + 4)) / 2;
        const padY = 10;
        return (
          <g key={bi}>
            <rect
              x={b.x} y={260 - b.h} width={b.w} height={b.h}
              fill={bi % 3 === 0 ? "#0A1810" : bi % 3 === 1 ? "#0D1F17" : "#081208"}
            />
            {Array.from({ length: rows }).map((_, ri) =>
              Array.from({ length: cols }).map((_, ci) => {
                const lit = (bi * 13 + ri * 5 + ci * 7) % 4 === 0;
                if (!lit) return null;
                const delay = ((bi * 7 + ri * 3 + ci * 2) % 20) * 0.35;
                const dur = 3 + ((bi + ri + ci) % 4);
                return (
                  <rect
                    key={`${ri}-${ci}`}
                    x={b.x + padX + ci * (winW + 4)}
                    y={260 - b.h + padY + ri * (winH + 6)}
                    width={winW}
                    height={winH}
                    fill="#E8A33D"
                    style={{
                      animation: `ct-twinkle ${dur}s ease-in-out ${delay}s infinite`,
                    }}
                  />
                );
              })
            )}
          </g>
        );
      })}
    </svg>
  );
}

function AnimatedBackground() {
  const lamps = [8, 20, 33, 47, 60, 74, 88];
  return (
    <div className="fixed inset-0 z-0 pointer-events-none overflow-hidden">
      {/* Night sky gradient */}
      <div className="absolute inset-0 ct-gradient-bg" />

      {/* Drifting fog layers (parallax) */}
      <div className="absolute inset-x-0 bottom-0 h-1/2 ct-fog ct-fog-a" />
      <div className="absolute inset-x-0 bottom-0 h-1/3 ct-fog ct-fog-b" />

      {/* City skyline with twinkling windows */}
      <div className="absolute inset-x-0 bottom-0 h-[40vh] md:h-[46vh]">
        <Skyline />
      </div>

      {/* Streetlamp glow along the ground line */}
      <div className="absolute inset-x-0 bottom-0 h-2">
        {lamps.map((left, i) => (
          <span
            key={i}
            className="absolute rounded-full ct-lamp"
            style={{
              left: `${left}%`,
              bottom: 0,
              width: 90,
              height: 90,
              marginLeft: -45,
              marginBottom: -45,
              background: "radial-gradient(circle, rgba(232,163,61,0.35) 0%, transparent 70%)",
              animationDelay: `${i * 0.7}s`,
            }}
          />
        ))}
      </div>

      {/* Passing light trail, like a distant car */}
      <div className="absolute bottom-[6%] left-0 w-full h-[2px] overflow-hidden">
        <div className="ct-car-trail" />
      </div>

      {/* Dark scrim so foreground text stays legible */}
      <div
        className="absolute inset-0"
        style={{
          background:
            "linear-gradient(180deg, rgba(13,31,23,0.55) 0%, rgba(13,31,23,0.35) 45%, rgba(13,31,23,0.9) 100%)",
        }}
      />
    </div>
  );
}

/* ---------------------------------------------------------
   Custom animated cursor — a soft glowing orb that trails the
   pointer, morphing color/size/blend-mode over interactive
   elements and picking up a contextual label via
   data-cursor-label. Disabled automatically on touch devices.
--------------------------------------------------------- */

function CustomCursor() {
  const orbRef = useRef(null);
  const dotRef = useRef(null);
  const pos = useRef({ x: 0, y: 0 });
  const orb = useRef({ x: 0, y: 0 });
  const [enabled, setEnabled] = useState(false);
  const [hovering, setHovering] = useState(false);
  const [label, setLabel] = useState("");

  useEffect(() => {
    const isFine = window.matchMedia && window.matchMedia("(pointer: fine)").matches;
    setEnabled(isFine);
    if (!isFine) return;

    const move = (e) => {
      pos.current = { x: e.clientX, y: e.clientY };
      if (dotRef.current) {
        dotRef.current.style.transform = `translate(${e.clientX}px, ${e.clientY}px) translate(-50%,-50%)`;
      }
      const hoverEl = e.target.closest("button, a, [data-cursor-hover]");
      setHovering(!!hoverEl);
      setLabel(hoverEl?.getAttribute("data-cursor-label") || "");
    };

    let raf;
    const tick = () => {
      orb.current.x += (pos.current.x - orb.current.x) * 0.12;
      orb.current.y += (pos.current.y - orb.current.y) * 0.12;
      if (orbRef.current) {
        orbRef.current.style.transform = `translate(${orb.current.x}px, ${orb.current.y}px) translate(-50%,-50%)`;
      }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);

    window.addEventListener("mousemove", move);
    return () => {
      window.removeEventListener("mousemove", move);
      cancelAnimationFrame(raf);
    };
  }, []);

  if (!enabled) return null;

  const size = hovering ? 84 : 20;

  return (
    <>
      <div
        ref={orbRef}
        className="fixed top-0 left-0 z-[9998] pointer-events-none rounded-full flex items-center justify-center"
        style={{
          width: size,
          height: size,
          background: hovering
            ? "radial-gradient(circle, rgba(149,213,178,0.9) 0%, rgba(45,106,79,0.35) 55%, transparent 75%)"
            : "radial-gradient(circle, rgba(255,255,255,0.9) 0%, rgba(255,255,255,0.15) 55%, transparent 75%)",
          mixBlendMode: hovering ? "screen" : "difference",
          filter: hovering ? "blur(0px)" : "blur(1px)",
          transition: "width .3s cubic-bezier(.22,1,.36,1), height .3s cubic-bezier(.22,1,.36,1), background .3s",
        }}
      >
        {hovering && label && (
          <span className="text-[10px] font-semibold text-black/80 tracking-wide select-none">
            {label}
          </span>
        )}
      </div>
      <div
        ref={dotRef}
        className="fixed top-0 left-0 z-[9999] pointer-events-none rounded-full bg-white"
        style={{
          width: hovering ? 0 : 5,
          height: hovering ? 0 : 5,
          transition: "width .2s, height .2s",
        }}
      />
    </>
  );
}

const gradientStyle = {
  backgroundImage:
    "linear-gradient(to right, #0D1F17 0%, #1B4332 12.5%, #95D5B2 32.5%, #2D6A4F 50%, #1B4332 67.5%, #0D1F17 87.5%, #0D1F17 100%)",
  backgroundSize: "200% auto",
  WebkitBackgroundClip: "text",
  backgroundClip: "text",
  color: "transparent",
  WebkitTextFillColor: "transparent",
  filter: "url(#ct-noise)",
};

/**
 * Tilt — wraps a card so it responds to the pointer: a subtle 3D
 * tilt plus a spotlight highlight that follows the cursor. Resets
 * smoothly on mouse leave. Used to make liquid-glass cards feel alive.
 */
function Tilt({ children, className = "", maxTilt = 8 }) {
  const ref = useRef(null);
  const [style, setStyle] = useState({});
  const [spot, setSpot] = useState({ x: 50, y: 50, on: false });

  const onMove = (e) => {
    const el = ref.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const px = (e.clientX - rect.left) / rect.width;
    const py = (e.clientY - rect.top) / rect.height;
    const rx = (0.5 - py) * maxTilt;
    const ry = (px - 0.5) * maxTilt;
    setStyle({
      transform: `perspective(800px) rotateX(${rx}deg) rotateY(${ry}deg) translateZ(0)`,
      transition: "transform 0.05s linear",
    });
    setSpot({ x: px * 100, y: py * 100, on: true });
  };

  const onLeave = () => {
    setStyle({
      transform: "perspective(800px) rotateX(0deg) rotateY(0deg)",
      transition: "transform 0.5s cubic-bezier(.22,1,.36,1)",
    });
    setSpot((s) => ({ ...s, on: false }));
  };

  return (
    <div
      ref={ref}
      onMouseMove={onMove}
      onMouseLeave={onLeave}
      data-cursor-hover
      className={className}
      style={{ ...style, position: "relative" }}
    >
      {children}
      <div
        className="pointer-events-none absolute inset-0 rounded-[inherit]"
        style={{
          background: `radial-gradient(300px circle at ${spot.x}% ${spot.y}%, rgba(149,213,178,0.15), transparent 70%)`,
          opacity: spot.on ? 1 : 0,
          transition: "opacity 0.3s",
        }}
      />
    </div>
  );
}

/* ---------------------------------------------------------
   Section: Navbar
--------------------------------------------------------- */

const NAV_LINKS = [
  { label: "Map", to: "/app" },
  { label: "Report", to: "/app" },
  { label: "Track", to: "/app" },
  { label: "Analytics", to: "#analytics" },
  { label: "For Authorities", to: "#authorities" },
];

function NavLink({ to, className, onClick, children }) {
  // In-app destinations use react-router's Link (no full page reload).
  // "#section" destinations smooth-scroll to a section on this same page.
  if (to.startsWith("#")) {
    return (
      <a
        href={to}
        data-cursor-hover
        className={className}
        onClick={(e) => {
          e.preventDefault();
          document.querySelector(to)?.scrollIntoView({ behavior: "smooth" });
          onClick?.();
        }}
      >
        {children}
      </a>
    );
  }
  return (
    <Link to={to} data-cursor-hover className={className} onClick={onClick}>
      {children}
    </Link>
  );
}

function Navbar() {
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <FadeIn delay={0} y={-10}>
      <nav className="relative max-w-6xl mx-auto px-6 py-5 flex items-center justify-between">
        <Link to="/" data-cursor-hover className="flex items-center">
          <LogoMark className="w-8 h-8" />
        </Link>
        <div className="hidden md:flex gap-8">
          {NAV_LINKS.map((l, i) => (
            <FadeIn key={l.label} delay={0.1 + i * 0.05} y={-6}>
              <NavLink
                to={l.to}
                className="relative text-white/70 text-sm font-medium hover:text-white transition-colors group/nav"
              >
                {l.label}
                <span className="absolute left-0 -bottom-1 h-px w-0 bg-white transition-all duration-300 group-hover/nav:w-full" />
              </NavLink>
            </FadeIn>
          ))}
        </div>
        <div className="hidden md:block">
          <Link to="/app"><ReportButton /></Link>
        </div>
        <button
          type="button"
          aria-label={mobileOpen ? "Close menu" : "Open menu"}
          aria-expanded={mobileOpen}
          onClick={() => setMobileOpen((v) => !v)}
          className="md:hidden w-10 h-10 rounded-full border border-white/10 bg-white/5 flex items-center justify-center"
        >
          {mobileOpen ? (
            <X className="w-4 h-4 text-white" />
          ) : (
            <Menu className="w-4 h-4 text-white" />
          )}
        </button>

        {mobileOpen && (
          <div className="md:hidden absolute top-full left-4 right-4 mt-2 rounded-2xl border border-white/10 bg-[#0e140f]/95 backdrop-blur-2xl p-4 flex flex-col gap-1 z-50">
            {NAV_LINKS.map((l) => (
              <NavLink
                key={l.label}
                to={l.to}
                onClick={() => setMobileOpen(false)}
                className="text-white/80 text-sm font-medium hover:text-white transition-colors px-3 py-2.5 rounded-lg hover:bg-white/5"
              >
                {l.label}
              </NavLink>
            ))}
            <Link to="/app" onClick={() => setMobileOpen(false)} className="mt-2">
              <ReportButton full />
            </Link>
          </div>
        )}
      </nav>
    </FadeIn>
  );
}

/* ---------------------------------------------------------
   Section: Hero
--------------------------------------------------------- */

function Hero() {
  return (
    <section className="pt-16 md:pt-28 pb-20 text-center flex flex-col items-center px-6">
      <FadeIn delay={0.3} y={24}>
        <h1 className="text-4xl md:text-7xl font-semibold tracking-tight leading-[0.9]">
          <span className="block text-white">Your city, reported.</span>
          <span className="block animate-shiny" style={gradientStyle}>
            Resolved.
          </span>
        </h1>
      </FadeIn>
      <FadeIn delay={0.5} y={16}>
        <p className="mt-8 text-white/60 max-w-md text-base leading-[1.5]">
          CivicTrack turns scattered complaints into a live map. Report a broken
          streetlight, water leak, or pothole in under a minute — and watch it
          move from reported to resolved.
        </p>
      </FadeIn>
      <FadeIn delay={0.7} y={12}>
        <div className="mt-8 flex flex-col items-center gap-3">
          <Link to="/app"><ReportButton label="Report an issue near you" /></Link>
          <span className="text-xs text-white/40">
            Free for citizens · No account needed to browse the map
          </span>
        </div>
      </FadeIn>
    </section>
  );
}

/* ---------------------------------------------------------
   Section: Live status strip
--------------------------------------------------------- */

function StatusStrip() {
  const items = ["Map", "List", "Analytics", "Help"];
  return (
    <FadeIn delay={0.9} y={0}>
      <div className="h-10 bg-black/40 backdrop-blur-md border-t border-b border-white/10">
        <div className="max-w-6xl mx-auto px-6 h-full flex items-center justify-between text-xs">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1.5">
              <LogoMark className="w-3.5 h-3.5" />
              <span className="font-bold text-white">CivicTrack</span>
            </div>
            {items.map((it, i) => (
              <span
                key={it}
                className={`text-white/60 ${i > 2 ? "hidden sm:inline" : ""} ${i > 3 ? "hidden md:inline" : ""}`}
              >
                {it}
              </span>
            ))}
          </div>
          <div className="flex items-center gap-2 text-white/50">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#95D5B2] opacity-75" />
              <span className="relative inline-flex rounded-full h-2 w-2 bg-[#95D5B2]" />
            </span>
            <span>1,204 issues resolved this month</span>
          </div>
        </div>
      </div>
    </FadeIn>
  );
}

/* ---------------------------------------------------------
   Section: App mockup
--------------------------------------------------------- */

function AppMockup() {
  const issues = [
    {
      title: "Broken streetlight, MG Road", desc: "Pole #14 dark for 3 nights", up: 34, status: "In Progress",
      time: "2h ago", color: "#E8A33D", category: "Streetlight", reporter: "Reported anonymously", location: "MG Road · 2 hours ago",
      severity: "Medium — repeated outage on a well-used stretch. Recommend standard-priority dispatch.",
      body: "The streetlight outside the MG Road bus stop has been dark for three consecutive nights. Pedestrians have flagged it as a safety concern after dusk.",
      logs: [["Ward Electrical Team", "acknowledged — 1h ago"], ["Citizen comment", "Still dark as of tonight."]],
    },
    {
      title: "Water leakage, Sector 12", desc: "Pipe burst near park gate", up: 61, status: "Reported",
      time: "5h ago", color: "#00B4D8", category: "Water Leakage", reporter: "Reported anonymously", location: "Sector 12 · 5 hours ago",
      severity: "High — standing water near a footpath, risk of erosion. Recommend priority dispatch.",
      body: "A burst pipe near the park entrance has been flooding the adjoining footpath since this morning. Water pressure appears high, and standing water is starting to erode the path edge.",
      logs: [["Municipal Water Dept.", "acknowledged — 2h ago"], ["Citizen comment", "Still leaking as of this morning."]],
    },
    {
      title: "Garbage pile-up, Green Colony", desc: "Overflowing bin, 3 days", up: 22, status: "In Progress",
      time: "Yesterday", color: "#8D6E4B", category: "Garbage", reporter: "Reported by Arjun M.", location: "Green Colony · Yesterday",
      severity: "Medium — overflow attracting pests. Recommend next-cycle collection.",
      body: "The community bin near the Green Colony gate has not been cleared in three days and is now overflowing onto the pavement.",
      logs: [["Sanitation Dept.", "scheduled for pickup — 6h ago"]],
    },
    {
      title: "Pothole, Ring Road", desc: "Deep pothole near bus stop", up: 89, status: "Reported",
      time: "Yesterday", color: "#95D5B2", category: "Road / Pothole", reporter: "Reported anonymously", location: "Ring Road · Yesterday",
      severity: "Critical — deep pothole in a high-traffic lane. Recommend immediate dispatch.",
      body: "A deep pothole has formed near the Ring Road bus stop, large enough to damage vehicle tires and force cyclists into traffic to avoid it.",
      logs: [["Citizen comment", "Two scooters damaged here already."]],
    },
    {
      title: "Streetlight, Lake View", desc: "Flickering light, safety risk", up: 8, status: "Resolved",
      time: "Mon", color: "#E8A33D", category: "Streetlight", reporter: "Reported by Kavya S.", location: "Lake View · Monday",
      severity: "Low — resolved. Ballast replaced during routine maintenance.",
      body: "A flickering streetlight near the Lake View path was reported and has since been repaired by the ward electrical team.",
      logs: [["Ward Electrical Team", "resolved — replaced faulty ballast"]],
    },
    {
      title: "Water leakage, Old Market", desc: "Leak flooding footpath", up: 15, status: "Resolved",
      time: "Mon", color: "#00B4D8", category: "Water Leakage", reporter: "Reported anonymously", location: "Old Market · Monday",
      severity: "Low — resolved. Pipe joint sealed.",
      body: "A minor leak flooding the Old Market footpath has been sealed and the area cleared.",
      logs: [["Municipal Water Dept.", "resolved — joint resealed"]],
    },
  ];

  const [selected, setSelected] = useState(1);
  const [upvoted, setUpvoted] = useState({});
  const issue = issues[selected];

  const statusColor = (s) =>
    s === "Resolved" ? "#2D6A4F" : s === "In Progress" ? "#E8A33D" : "#95D5B2";

  const toggleUpvote = () => setUpvoted((u) => ({ ...u, [selected]: !u[selected] }));
  const stepIndex = { Reported: 0, "In Progress": 1, Resolved: 2 }[issue.status];

  return (
    <section className="max-w-6xl mx-auto px-6 py-16 md:py-24">
      <FadeIn delay={1.1} y={40}>
        <div className="relative rounded-2xl overflow-hidden border border-white/10 bg-[#0e140f]/90 backdrop-blur-2xl">
          {/* Title bar */}
          <div className="h-10 flex items-center px-4 border-b border-white/10 relative">
            <div className="flex gap-2">
              <span className="w-3 h-3 rounded-full" style={{ background: "#ff5f57" }} />
              <span className="w-3 h-3 rounded-full" style={{ background: "#febc2e" }} />
              <span className="w-3 h-3 rounded-full" style={{ background: "#28c840" }} />
            </div>
            <span className="absolute left-1/2 -translate-x-1/2 text-xs text-white/50">
              CivicTrack — Local Map
            </span>
          </div>

          <div className="grid grid-cols-12 h-[560px] md:h-[520px]">
            {/* Sidebar */}
            <div className="hidden md:flex col-span-3 border-r border-white/10 bg-black/30 p-4 flex-col gap-5">
              <button data-cursor-hover data-cursor-label="Report" className="w-full rounded-lg bg-white text-black text-xs font-semibold px-3 py-2 flex items-center justify-center gap-2 hover:bg-white/90 transition-colors">
                <Camera className="w-3.5 h-3.5" />
                Report an Issue
              </button>
              <div className="flex flex-col gap-1 text-xs">
                {[
                  { icon: Inbox, label: "All Issues", count: 128, active: true },
                  { icon: MapPin, label: "My Reports", count: 4 },
                  { icon: Star, label: "Upvoted", count: 9 },
                  { icon: Check, label: "Resolved", count: 86 },
                  { icon: Archive, label: "Archive" },
                ].map(({ icon: Icon, label, count, active }) => (
                  <div
                    key={label}
                    data-cursor-hover
                    className={`flex items-center justify-between px-2 py-1.5 rounded-lg cursor-pointer transition-colors ${
                      active ? "bg-white/10 text-white" : "text-white/60 hover:bg-white/5"
                    }`}
                  >
                    <span className="flex items-center gap-2">
                      <Icon className="w-3.5 h-3.5" />
                      {label}
                    </span>
                    {count !== undefined && <span>{count}</span>}
                  </div>
                ))}
              </div>
              <div>
                <div className="text-[10px] uppercase tracking-wide text-white/40 mb-2">Categories</div>
                <div className="flex flex-col gap-1.5 text-xs text-white/70">
                  {[
                    { label: "Streetlight", color: "#E8A33D" },
                    { label: "Water Leakage", color: "#00B4D8" },
                    { label: "Garbage", color: "#8D6E4B" },
                    { label: "Road / Pothole", color: "#95D5B2" },
                  ].map((c) => (
                    <div key={c.label} className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full" style={{ background: c.color }} />
                      {c.label}
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Issue list — click to update the detail panel */}
            <div className="col-span-12 md:col-span-4 border-r border-white/10 overflow-y-auto">
              <div className="flex items-center gap-2 px-3 py-2.5 border-b border-white/10 text-xs text-white/40">
                <Search className="w-3.5 h-3.5" />
                Search issues near you
              </div>
              {issues.map((it, i) => (
                <div
                  key={it.title}
                  onClick={() => setSelected(i)}
                  data-cursor-hover
                  data-cursor-label="View"
                  className={`px-3 py-3 border-b border-white/5 cursor-pointer transition-colors ${
                    i === selected ? "bg-white/[0.08]" : "hover:bg-white/[0.03]"
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full" style={{ background: it.color }} />
                      <span className="text-xs font-semibold text-white">{it.title}</span>
                    </div>
                    <span className="text-[10px] text-white/40">{it.time}</span>
                  </div>
                  <p className="text-[11px] text-white/50 mt-1 ml-4">{it.desc}</p>
                  <div className="flex items-center justify-between mt-2 ml-4">
                    <span
                      className="text-[10px] px-2 py-0.5 rounded-full"
                      style={{ background: `${statusColor(it.status)}22`, color: statusColor(it.status) }}
                    >
                      {it.status}
                    </span>
                    <span className="text-[10px] text-white/40 flex items-center gap-1">
                      <ArrowUp className="w-3 h-3" />
                      {it.up + (upvoted[i] ? 1 : 0)}
                    </span>
                  </div>
                </div>
              ))}
            </div>

            {/* Detail panel — reflects the selected issue */}
            <div className="hidden md:flex col-span-5 flex-col p-5 overflow-y-auto">
              <div className="flex items-center gap-2 pb-3 border-b border-white/10">
                {[ArrowUp, Share2, Flag, Archive].map((Icon, i) => (
                  <button key={i} data-cursor-hover className="w-7 h-7 rounded-md hover:bg-white/5 flex items-center justify-center transition-colors">
                    <Icon className="w-3.5 h-3.5 text-white/60" />
                  </button>
                ))}
                <div className="flex-1" />
                <MoreHorizontal className="w-4 h-4 text-white/40" />
              </div>

              <div className="mt-4">
                <h3 className="text-base font-semibold text-white">{issue.title.split(",")[0]}</h3>
                <div className="flex items-center gap-2 mt-2">
                  <div
                    className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold"
                    style={{ background: `linear-gradient(135deg, ${issue.color}, #0D1F17)` }}
                  >
                    {issue.category[0]}
                  </div>
                  <div className="text-xs">
                    <div className="text-white/80">{issue.reporter}</div>
                    <div className="text-white/40">{issue.location}</div>
                  </div>
                  <span className="ml-auto text-[10px] px-2 py-0.5 rounded-full border border-white/10 text-white/60">
                    {issue.category}
                  </span>
                </div>
              </div>

              <div className="liquid-glass rounded-lg p-3 mt-4">
                <div className="flex items-center gap-2 text-xs font-semibold text-white">
                  <Sparkles className="w-3.5 h-3.5" style={{ color: "#95D5B2" }} />
                  AI Severity Assessment
                </div>
                <p className="text-[11px] text-white/60 mt-1.5 leading-relaxed">{issue.severity}</p>
              </div>

              {/* Stepper */}
              <div className="flex items-center mt-5 text-[11px]">
                {["Reported", "In Progress", "Resolved"].map((s, i) => (
                  <React.Fragment key={s}>
                    <div className="flex flex-col items-center gap-1">
                      <div
                        className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] transition-colors ${
                          i <= stepIndex ? "bg-white text-black" : "bg-white/10 text-white/40"
                        }`}
                      >
                        {i + 1}
                      </div>
                      <span className={i <= stepIndex ? "text-white" : "text-white/40"}>{s}</span>
                    </div>
                    {i < 2 && (
                      <div
                        className="flex-1 h-px mx-2 mb-4 transition-colors"
                        style={{ background: i < stepIndex ? "rgba(255,255,255,0.5)" : "rgba(255,255,255,0.1)" }}
                      />
                    )}
                  </React.Fragment>
                ))}
              </div>

              <p className="text-xs text-white/50 mt-5 leading-relaxed">{issue.body}</p>

              <div className="flex items-center justify-between mt-4 liquid-glass rounded-lg p-3">
                <span className="text-xs text-white/70">{issue.up + (upvoted[selected] ? 1 : 0)} people affected</span>
                <button
                  onClick={toggleUpvote}
                  data-cursor-hover
                  data-cursor-label={upvoted[selected] ? "Upvoted" : "Upvote"}
                  className={`text-[11px] px-3 py-1.5 rounded-full font-medium flex items-center gap-1 transition-colors ${
                    upvoted[selected] ? "bg-[#95D5B2] text-black" : "bg-white text-black hover:bg-white/90"
                  }`}
                >
                  <ArrowUp className="w-3 h-3" />
                  {upvoted[selected] ? "Upvoted" : "Upvote"}
                </button>
              </div>

              <div className="mt-4 text-[11px] text-white/50 space-y-2">
                {issue.logs.map(([who, what]) => (
                  <p key={who + what}>
                    <span className="text-white/70 font-medium">{who}</span> — "{what}"
                  </p>
                ))}
              </div>
            </div>
          </div>
        </div>
      </FadeIn>
    </section>
  );
}

/* ---------------------------------------------------------
   Section: FeatureTriage
--------------------------------------------------------- */

function FeatureTriage() {
  const chips = ["Auto-categorize", "Duplicate detection", "Severity scoring", "Priority routing"];
  const buckets = [
    { label: "Critical", count: 3, color: "#ffffff", items: ["Live wire near school", "Gas smell reported, Elm St"] },
    { label: "High", count: 11, color: "#E8A33D", items: ["Pipe burst, Sector 12", "Deep pothole, Ring Road"] },
    { label: "Medium", count: 19, color: "#95D5B2", items: ["Streetlight flicker, Lake View", "Bin overflow, Green Colony"] },
    { label: "Low", count: 13, color: "#525252", items: ["Faded road marking", "Minor litter, park entrance"] },
  ];

  return (
    <section id="analytics" className="max-w-6xl mx-auto px-6 py-20 md:py-28 grid md:grid-cols-2 gap-10 md:gap-16 items-start scroll-mt-24">
      <FadeIn delay={0} y={20}>
        <SectionEyebrow label="Triage" tag="AI-native" />
        <h2 className="mt-5 text-3xl md:text-5xl font-semibold tracking-tight leading-[1.02] text-white">
          Know what to fix
          <br />
          first.
        </h2>
        <p className="mt-6 text-white/60 text-base leading-[1.6] max-w-md">
          CivicTrack reads every photo and description, estimates severity, and
          clusters duplicate reports — so the most urgent, most-affecting issues
          rise to the top automatically.
        </p>
        <div className="flex flex-wrap gap-2 mt-6">
          {chips.map((c) => (
            <span key={c} className="text-xs text-white/70 px-3 py-1.5 rounded-full border border-white/10 bg-white/[0.03]">
              {c}
            </span>
          ))}
        </div>
      </FadeIn>

      <FadeIn delay={0.15} y={20}>
        <Tilt className="liquid-glass rounded-2xl p-5">
          <div className="text-xs text-white/50 mb-4">Today · 46 issues triaged</div>
          <div className="grid grid-cols-2 gap-3">
            {buckets.map((b) => (
              <div key={b.label} className="liquid-glass rounded-lg p-3">
                <div className="flex items-center justify-between text-xs font-semibold" style={{ color: b.color }}>
                  {b.label}
                  <span className="text-white/40 font-normal">{b.count}</span>
                </div>
                <ul className="mt-2 space-y-1">
                  {b.items.map((it) => (
                    <li key={it} className="text-[11px] text-white/50 leading-snug">
                      {it}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </Tilt>
      </FadeIn>
    </section>
  );
}

/* ---------------------------------------------------------
   Section: LogoCloud (fictional partners)
--------------------------------------------------------- */

function LogoCloud() {
  const names = [
    "Woodhaven Ward Council", "Rivertown Residents' Assoc.", "Maple District Office",
    "GreenPath Community Trust", "Lakeside Civic Forum", "Northgate NGO",
    "Elmwood Ward", "Harborview Council",
  ];
  return (
    <section className="max-w-6xl mx-auto px-6 py-16 md:py-20 text-center">
      <FadeIn delay={0}>
        <div className="text-xs uppercase tracking-widest text-white/40">
          Piloted with local wards and community groups
        </div>
      </FadeIn>
      <div className="mt-10 grid grid-cols-2 sm:grid-cols-4 gap-6">
        {names.map((n, i) => (
          <FadeIn key={n} delay={i * 0.05}>
            <span className="text-sm font-semibold tracking-tight text-white/50 hover:text-white transition-colors">
              {n}
            </span>
          </FadeIn>
        ))}
      </div>
    </section>
  );
}

/* ---------------------------------------------------------
   Section: Testimonials (fictional)
--------------------------------------------------------- */

function Testimonials() {
  const quotes = [
    {
      text: "I reported a pothole on my way to college and watched it get fixed in four days. I didn't have to call anyone.",
      name: "Ananya Rao",
      role: "Resident",
      org: "WOODHAVEN WARD",
    },
    {
      text: "The severity scoring helped us dispatch crews to the water leak that actually mattered first, not just the loudest complaint.",
      name: "Devraj Malhotra",
      role: "Sanitation Officer",
      org: "RIVERTOWN MUNICIPAL OFFICE",
    },
    {
      text: "Upvoting stopped the duplicate reports. Now we see one pin with 40 people behind it instead of 40 separate tickets.",
      name: "Fatima Sheikh",
      role: "Coordinator",
      org: "GREENPATH COMMUNITY TRUST",
    },
  ];
  return (
    <section className="max-w-6xl mx-auto px-6 py-20 md:py-28 border-t border-white/10">
      <div className="grid md:grid-cols-3 gap-6">
        {quotes.map((q, i) => (
          <FadeIn key={q.name} delay={i * 0.1}>
            <Tilt className="liquid-glass rounded-2xl p-6 h-full flex flex-col" maxTilt={6}>
              <blockquote className="text-sm text-white/80 leading-[1.6]">"{q.text}"</blockquote>
              <figcaption className="mt-6 pt-5 border-t border-white/10">
                <div className="text-sm font-semibold text-white">{q.name}</div>
                <div className="text-xs text-white/50">{q.role}</div>
                <div className="text-xs text-white font-semibold tracking-wide mt-1">{q.org}</div>
              </figcaption>
            </Tilt>
          </FadeIn>
        ))}
      </div>
    </section>
  );
}

/* ---------------------------------------------------------
   Section: Plans
--------------------------------------------------------- */

function Plans() {
  const plans = [
    {
      tier: "Citizen",
      price: "Free",
      desc: "For anyone who wants to report and track issues nearby.",
      features: ["Unlimited reports", "Map access", "Upvoting", "Status notifications", "Anonymous reporting"],
      pro: false,
    },
    {
      tier: "Community",
      price: "Apply for access",
      desc: "For RWAs, NGOs, and neighborhood groups coordinating local issues.",
      features: ["Everything in Citizen", "Group dashboards", "QR codes for hotspots", "Shared upvote campaigns", "Priority support"],
      pro: false,
    },
    {
      tier: "Municipal",
      price: "Contact us",
      desc: "For ward offices and municipal authorities managing resolution.",
      features: ["Everything in Community", "Full analytics dashboard", "Heatmaps & resolution SLAs", "Team assignment & status control", "API access"],
      pro: true,
    },
  ];

  return (
    <section id="authorities" className="ct-plans-section relative scroll-mt-24">
      <svg width="0" height="0" style={{ position: "absolute" }}>
        <filter id="ct-noise-2">
          <feTurbulence type="fractalNoise" baseFrequency="0.5" numOctaves="2" stitchTiles="stitch" />
          <feComponentTransfer>
            <feFuncA type="linear" slope="0.075" />
          </feComponentTransfer>
          <feComposite in2="SourceGraphic" operator="in" result="noise" />
          <feBlend in="SourceGraphic" in2="noise" mode="overlay" />
        </filter>
      </svg>

      <div className="max-w-6xl mx-auto px-6 py-16 md:py-24 relative z-[2] text-center">
        <div
          className="text-5xl md:text-8xl font-extrabold leading-[0.9] tracking-tight"
          style={{ filter: "url(#ct-noise-2)" }}
        >
          <div className="text-white">Your city.</div>
          <div style={gradientStyle}>Resolved.</div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-6 pb-24 relative z-[3]">
        <div className="grid md:grid-cols-3 gap-6">
          {plans.map((p) => (
            <FadeIn key={p.tier} delay={0.1}>
              <Tilt
                maxTilt={5}
                className={`rounded-[32px] p-8 md:p-10 min-h-[480px] flex flex-col border ${
                  p.pro ? "border-[#95D5B2]/40" : "border-white/15"
                }`}
              >
                <div
                  className="absolute inset-0 rounded-[32px] -z-10"
                  style={{
                    background: p.pro
                      ? "linear-gradient(135deg, rgba(0,0,0,0.85), rgba(0,0,0,0.55))"
                      : "linear-gradient(135deg, rgba(0,0,0,0.7), rgba(0,0,0,0.4))",
                    backdropFilter: "blur(14px) brightness(0.91)",
                  }}
                />
                <div className="text-white/60 text-base">{p.tier}</div>
                <div className="text-2xl md:text-3xl font-medium text-white mt-2">{p.price}</div>
                <p className="text-xs text-white/45 mt-4 mb-8 leading-relaxed min-h-[3.2em]">{p.desc}</p>
                <ul className="space-y-3 flex-1">
                  {p.features.map((f) => (
                    <li key={f} className="flex items-start gap-3 text-sm text-white/80">
                      <span className="w-6 h-6 rounded-full bg-white/15 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <Check className="w-3 h-3 text-white" />
                      </span>
                      {f}
                    </li>
                  ))}
                </ul>
                {p.tier === "Citizen" ? (
                  <Link
                    to="/app"
                    data-cursor-hover
                    className="mt-8 self-center bg-white text-black px-8 py-2.5 rounded-full font-semibold text-sm hover:bg-white/90 transition-colors"
                  >
                    Get started
                  </Link>
                ) : (
                  <button
                    type="button"
                    data-cursor-hover
                    onClick={() => document.querySelector("#authorities")?.scrollIntoView({ behavior: "smooth" })}
                    className="mt-8 self-center bg-white text-black px-8 py-2.5 rounded-full font-semibold text-sm hover:bg-white/90 transition-colors"
                  >
                    Request access
                  </button>
                )}
              </Tilt>
            </FadeIn>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------------------------------------------------------
   Section: FinalCTA
--------------------------------------------------------- */

function FinalCTA() {
  return (
    <section className="max-w-6xl mx-auto px-6 py-20 md:py-32">
      <FadeIn delay={0}>
        <Tilt maxTilt={4} className="liquid-glass relative overflow-hidden rounded-3xl px-8 py-16 md:py-24 text-center">
          <div
            className="absolute inset-0 pointer-events-none"
            style={{
              background: "radial-gradient(600px circle at 50% 0%, rgba(255,255,255,0.15), transparent 70%)",
              opacity: 0.3,
            }}
          />
          <div className="relative">
            <h2 className="text-4xl md:text-6xl font-semibold tracking-tight leading-[1.02] text-white">
              Stop calling about it.
              <br />
              Start tracking it.
            </h2>
            <p className="mt-6 text-white/60 max-w-md mx-auto text-sm leading-[1.6]">
              Join citizens, community groups, and ward offices already turning
              complaints into resolved issues — with a record everyone can see.
            </p>
            <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-3">
              <Link to="/app"><ReportButton label="Report an issue near you" /></Link>
              <button
                type="button"
                data-cursor-hover
                data-cursor-label="Contact"
                onClick={() => document.querySelector("#authorities")?.scrollIntoView({ behavior: "smooth" })}
                className="rounded-full border border-white/15 text-white text-sm font-medium px-5 py-3 hover:bg-white/5 transition-colors flex items-center gap-2"
              >
                Request municipal access
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </Tilt>
      </FadeIn>
    </section>
  );
}

/* ---------------------------------------------------------
   Root
--------------------------------------------------------- */

export default function CivicTrackLanding() {
  return (
    <div className="ct-root relative min-h-screen overflow-x-hidden bg-[#0D1F17] text-white font-sans">
      <style>{`
        @keyframes shiny {
          0% { background-position: -200% center; }
          100% { background-position: 200% center; }
        }
        .animate-shiny { animation: shiny 6s linear infinite; }

        .ct-gradient-bg {
          background: #0D1F17;
          background-image:
            radial-gradient(1000px 700px at 15% 20%, rgba(45,106,79,0.45), transparent 60%),
            radial-gradient(900px 600px at 85% 15%, rgba(149,213,178,0.28), transparent 60%),
            radial-gradient(1100px 700px at 30% 90%, rgba(27,67,50,0.5), transparent 60%),
            radial-gradient(800px 600px at 90% 85%, rgba(232,163,61,0.14), transparent 60%);
          background-size: 180% 180%, 160% 160%, 200% 200%, 170% 170%;
          background-repeat: no-repeat;
          animation: ct-gradient-loop 22s ease-in-out infinite;
        }
        @keyframes ct-gradient-loop {
          0%   { background-position: 0% 0%, 100% 0%, 0% 100%, 100% 100%; }
          50%  { background-position: 40% 30%, 60% 40%, 40% 60%, 60% 70%; }
          100% { background-position: 0% 0%, 100% 0%, 0% 100%, 100% 100%; }
        }

        @keyframes ct-twinkle {
          0%, 100% { opacity: 0.15; }
          50% { opacity: 0.9; }
        }

        @keyframes ct-lamp-pulse {
          0%, 100% { opacity: 0.5; transform: scale(1); }
          50% { opacity: 1; transform: scale(1.15); }
        }
        .ct-lamp { animation: ct-lamp-pulse 3.5s ease-in-out infinite; }

        .ct-fog {
          background: radial-gradient(ellipse at center, rgba(149,213,178,0.08), transparent 70%);
          filter: blur(6px);
        }
        @keyframes ct-fog-drift-a {
          0% { transform: translateX(-10%); }
          50% { transform: translateX(10%); }
          100% { transform: translateX(-10%); }
        }
        @keyframes ct-fog-drift-b {
          0% { transform: translateX(8%); }
          50% { transform: translateX(-8%); }
          100% { transform: translateX(8%); }
        }
        .ct-fog-a { animation: ct-fog-drift-a 40s ease-in-out infinite; }
        .ct-fog-b { animation: ct-fog-drift-b 55s ease-in-out infinite; opacity: 0.6; }

        .ct-car-trail {
          position: absolute;
          top: 0;
          left: -20%;
          width: 14%;
          height: 100%;
          background: linear-gradient(90deg, transparent, rgba(255,255,255,0.6), transparent);
          animation: ct-car-move 9s linear infinite;
          animation-delay: 2s;
        }
        @keyframes ct-car-move {
          0% { left: -20%; opacity: 0; }
          10% { opacity: 1; }
          90% { opacity: 1; }
          100% { left: 110%; opacity: 0; }
        }

        .liquid-glass {
          background: rgba(255,255,255,0.01);
          background-blend-mode: luminosity;
          backdrop-filter: blur(4px);
          border: none;
          box-shadow: inset 0 1px 1px rgba(255,255,255,0.1);
          position: relative;
          overflow: hidden;
        }
        .liquid-glass::before {
          content: '';
          position: absolute;
          inset: 0;
          border-radius: inherit;
          padding: 1.4px;
          background: linear-gradient(180deg,
            rgba(255,255,255,0.45) 0%, rgba(255,255,255,0.15) 20%,
            rgba(255,255,255,0) 40%, rgba(255,255,255,0) 60%,
            rgba(255,255,255,0.15) 80%, rgba(255,255,255,0.45) 100%);
          -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
          -webkit-mask-composite: xor;
          mask-composite: exclude;
          pointer-events: none;
        }

        ::selection { background: rgba(45,106,79,0.3); }

        @media (pointer: fine) {
          .ct-root, .ct-root * { cursor: none !important; }
        }
      `}</style>

      <svg width="0" height="0" style={{ position: "absolute" }}>
        <filter id="ct-noise">
          <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="2" stitchTiles="stitch" />
          <feColorMatrix type="matrix" values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0 0.35 0" />
          <feComposite in2="SourceGraphic" operator="in" result="noise" />
          <feBlend in="SourceGraphic" in2="noise" mode="multiply" />
        </filter>
      </svg>

      {/* Animated canvas background instead of a third-party video */}
      <AnimatedBackground />
      <CustomCursor />

      <div className="hidden md:block pointer-events-none fixed inset-y-0 left-1/2 -translate-x-[calc(50%+36rem)] w-px bg-white/10 z-[5]" />
      <div className="hidden md:block pointer-events-none fixed inset-y-0 left-1/2 translate-x-[calc(-50%+36rem)] w-px bg-white/10 z-[5]" />

      <div className="relative z-10">
        <Navbar />
        <Hero />
        <StatusStrip />
        <AppMockup />
        <FeatureTriage />
        <LogoCloud />
        <Testimonials />
        <Plans />
        <FinalCTA />
      </div>
    </div>
  );
}
