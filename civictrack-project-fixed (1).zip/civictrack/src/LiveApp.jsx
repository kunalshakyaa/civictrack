import { useState } from "react";
import { Link } from "react-router-dom";
import MapView from "./MapView";
import ReportForm from "./ReportForm";
import IssueComments from "./IssueComments";

export default function LiveApp() {
  const [selected, setSelected] = useState(null);
  const [tab, setTab] = useState("map"); // "map" | "report"

  return (
    <div className="h-screen w-screen flex flex-col bg-[#0D1F17] text-white">
      <div className="h-14 flex items-center justify-between px-4 md:px-6 border-b border-white/10 flex-shrink-0">
        <Link to="/" className="font-semibold text-sm hover:text-white/80 transition-colors">
          ← CivicTrack
        </Link>
        <div className="flex gap-2 text-sm">
          <button
            onClick={() => setTab("map")}
            className={`px-3 py-1.5 rounded-full transition-colors ${
              tab === "map" ? "bg-white text-black" : "text-white/60 hover:text-white"
            }`}
          >
            Map
          </button>
          <button
            onClick={() => setTab("report")}
            className={`px-3 py-1.5 rounded-full transition-colors ${
              tab === "report" ? "bg-white text-black" : "text-white/60 hover:text-white"
            }`}
          >
            Report
          </button>
        </div>
      </div>

      <div className="flex-1 flex overflow-hidden">
        {tab === "map" ? (
          <>
            <div className="flex-1">
              <MapView onSelectIssue={setSelected} />
            </div>
            <div className="hidden md:block w-80 border-l border-white/10 overflow-hidden flex-shrink-0">
              <IssueComments issue={selected} />
            </div>
          </>
        ) : (
          <div className="flex-1 overflow-y-auto">
            <ReportForm onDone={() => setTab("map")} />
          </div>
        )}
      </div>
    </div>
  );
}
