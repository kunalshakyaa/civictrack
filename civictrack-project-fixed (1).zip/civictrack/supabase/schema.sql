-- CivicTrack database schema
-- Run this once in your Supabase project's SQL Editor (Supabase Dashboard -> SQL Editor -> New query).

create extension if not exists "pgcrypto";

create table if not exists issues (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  category text not null,          -- streetlight | water | garbage | road | other
  lat double precision not null,
  lng double precision not null,
  photo_url text,
  status text not null default 'Reported',   -- Reported | In Progress | Resolved
  upvotes integer not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists comments (
  id uuid primary key default gen_random_uuid(),
  issue_id uuid references issues(id) on delete cascade,
  author text not null default 'Anonymous',
  text text not null,
  created_at timestamptz not null default now()
);

-- Row Level Security
alter table issues enable row level security;
alter table comments enable row level security;

-- Demo-friendly OPEN policies: anyone can read/insert/update.
-- This matches an anonymous, no-login civic reporting app.
-- Before real-world production use, tighten these (e.g. rate limiting,
-- moderation, or requiring Supabase Auth for writes).
create policy "public read issues"   on issues   for select using (true);
create policy "public insert issues" on issues   for insert with check (true);
create policy "public update issues" on issues   for update using (true);

create policy "public read comments"   on comments for select using (true);
create policy "public insert comments" on comments for insert with check (true);

-- Enable realtime so the map and comment threads update live for everyone
alter publication supabase_realtime add table issues;
alter publication supabase_realtime add table comments;

-- Storage: after running this file, also create a public Storage bucket
-- named "photos" from the Supabase Dashboard (Storage -> New bucket ->
-- name "photos" -> toggle "Public bucket" on). That's where report photos
-- are uploaded to and served from.
